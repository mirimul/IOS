//
//  PlayersViewController.swift
//  TicTacToe
//
//  Created by Hope Mailei on 29/5/18.
//  Copyright © 2018 miriam tym. All rights reserved.
//

import UIKit

class PlayersViewController: UIViewController {

    @IBOutlet weak var targetScoreLabel: UILabel!
    @IBOutlet weak var targetScoreSlider: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func targetScoreSlider(_ sender: UISlider) {
        let currentValue = Int(sender.value)
        targetScoreLabel.text = "\(currentValue)"
    }
    @IBAction func nextButtonTapped(_ sender: Any) {
        let targetScore = Int(targetScoreLabel.text!)
        let defaults = UserDefaults.standard
        defaults.set(targetScore, forKey: "targetScore")
        performSegue(withIdentifier: "toPlayersInfoViewController", sender: nil)
    }
    
    

}
