//
//  IntroductionViewController.swift
//  TicTacToe
//
//  Created by Hope Mailei on 23/5/18.
//  Copyright © 2018 miriam tym. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import AudioToolbox

class PlayersInfoViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var playerOneTextField: UITextField!
    @IBOutlet weak var playerTwoTextField: UITextField!
    var playerOneChosen: String?
    var playerTwoChosen: String?
    var audioPlayer = AVAudioPlayer()
    
    var animalPicker: Array = ["ChoosePlayer.png","Bird.png","Cat.png","Elephant.png","Giraffe.png","Hedgehog","Horse.png","Koala.png","Monkey.png","Owl.png","Panda.png","Penguin.png","PolarBear.png","Tiger.png"]
    
    @IBOutlet weak var playerOnePicker: UIPickerView!
    @IBOutlet weak var playerTwoPicker: UIPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        playerOnePicker.delegate = self
        playerOnePicker.dataSource = self
        playerTwoPicker.delegate = self
        playerTwoPicker.dataSource = self

    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return animalPicker.count
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 120
    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        //Memory view
        let view = UIView(frame: CGRect(x: 0, y:0, width: 250, height: 100))
        
        let animalImage = UIImageView()
        animalImage.image = UIImage(named:animalPicker[row])
        animalImage.frame = CGRect(x: 75, y:0, width: 100, height: 100)
        
        view.addSubview(animalImage)

        //end memory view
        
        return view
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView {
        case playerOnePicker:
            playerOneChosen = animalPicker[row]
        case playerTwoPicker:
            playerTwoChosen = animalPicker[row]
        default:
            break
        }
        
        //------------------- making the sound
        let animalSoundName = String(animalPicker[row].split(separator:".")[0])
        let soundUrl = Bundle.main.url(forResource: animalSoundName, withExtension: ".mp3")
        if soundUrl != nil {
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: soundUrl!)
                audioPlayer.volume = 1
                audioPlayer.numberOfLoops = 0
                audioPlayer.play()
                
            } catch {
                print(error)
            }
        }
    }


    @IBAction func PlayButtonTapped(_ sender: Any) {
        if playerOneTextField.text == "" {
            UIView.animate(withDuration: 0.2, animations: {
                
                let rightTransform  = CGAffineTransform(translationX: 20, y: 0)
                self.playerOneTextField.transform = rightTransform
                
            }) { (_) in
                
                UIView.animate(withDuration: 0.2, animations: {
                    self.playerOneTextField.transform = CGAffineTransform.identity
                })
            }
        } else if playerTwoTextField.text == "" {
            UIView.animate(withDuration: 0.2, animations: {
                
                let rightTransform  = CGAffineTransform(translationX: 20, y: 0)
                self.playerTwoTextField.transform = rightTransform
                
            }) { (_) in
                
                UIView.animate(withDuration: 0.2, animations: {
                    self.playerTwoTextField.transform = CGAffineTransform.identity
                })
            }
        }
        else {
            performSegue(withIdentifier: "toViewController", sender: nil)
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let ViewController: ViewController = segue.destination as! ViewController
        let playerOne = playerOneTextField.text
        let playerTwo = playerTwoTextField.text
        ViewController.playerOne = playerOne
        ViewController.playerTwo = playerTwo
        let playerOneAnimal = playerOneChosen
        let playerTwoAnimal = playerTwoChosen
        ViewController.playerOneCharacter = playerOneAnimal
        ViewController.playerTwoCharacter = playerTwoAnimal
    }
    
}
