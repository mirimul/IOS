//
//  GameOverViewController.swift
//  TicTacToe
//
//  Created by Hope Mailei on 1/6/18.
//  Copyright © 2018 miriam tym. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import AudioToolbox

class GameOverViewController: UIViewController {
    
    var playerWinner: String?
    var winnerName: String?
    var audioPlayer = AVAudioPlayer()

    @IBOutlet weak var winnerImage: UIImageView!
    @IBOutlet weak var gameOverLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        winnerImage.image = UIImage(named: playerWinner!)
        gameOverLabel.text = "CONGRATULATIONS " + winnerName! + "!"
        
        // Do any additional setup after loading the view.
        
        //------------------------- making the sound ------------------------
        let animalSoundName = String((playerWinner?.split(separator:".")[0])!)
        let soundUrl = Bundle.main.url(forResource: animalSoundName, withExtension: ".mp3")
        if soundUrl != nil {
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: soundUrl!)
                audioPlayer.volume = 1
                audioPlayer.numberOfLoops = 0
                audioPlayer.play()
                
            } catch {
                print(error)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func homeButtonTapped(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindSegue", sender: self)
    }
    
    
    
}
