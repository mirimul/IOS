//
//  ViewController.swift
//  TicTacToe
//
//  Created by miriam tym on 10/5/18.
//  Copyright © 2018 miriam tym. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var activePlayer = 1 // Cross
    var playerOne: String?
    var playerTwo: String?
    var playerOneScore = 0
    var playerTwoScore = 0
    var gamesPlayed: [Int] = []
    var playerOneCharacter: String?
    var playerTwoCharacter: String?
    var targetScore: Int?
    var winningPlayer: String?
    var winnerName: String?
    
    var gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    
    let winningCombinations = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
    var gameIsActive = true
    var winner = false
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var playerOneLabel: UILabel!
    @IBOutlet weak var playerTwoLabel: UILabel!
    @IBOutlet weak var playerOneImage: UIImageView!
    @IBOutlet weak var playerTwoImage: UIImageView!
    
    @IBAction func action(_ sender: AnyObject) {
        
        if (gameState[sender.tag-1] == 0 && gameIsActive == true)
        {
            gameState[sender.tag-1] = activePlayer
            gamesPlayed.append(activePlayer)
            
        if (activePlayer == 1) {
            sender.setImage(UIImage(named: playerOneCharacter!), for: .normal)
            activePlayer = 2
            playerTwoImage.isHidden = false
            playerOneImage.isHidden = true
        }
        else
        {
            sender.setImage(UIImage(named: playerTwoCharacter!), for: .normal)
            activePlayer = 1
            playerOneImage.isHidden = false
            playerTwoImage.isHidden = true
        }
        }
        for i in gameState {
            if i == 0 {
                gameIsActive = true
                break
            } else {
                gameIsActive = false
            }
        }
        
        for combination in winningCombinations
        {
            if gameState[combination[0]] != 0 && gameState[combination[0]] == gameState[combination[1]] && gameState[combination[1]] == gameState[combination[2]]
            {
                gameIsActive = false
                playerTwoImage.isHidden = false
                playerOneImage.isHidden = false
                //function where you can no longer play the game
                
                if gameState[combination[0]] == 1
                {
                    label.text = playerOne! + " Has Won!"
                    playerOneScore += 1
                    playerOneLabel.text = playerOne! + ": " + String(playerOneScore)
                }
                else {
                    label.text = playerTwo! + " Has Won!"
                    playerTwoScore += 1
                    playerTwoLabel.text = playerTwo! + ": " + String(playerTwoScore)
                }
                playAgainButton.isHidden = false
                label.isHidden = false
                winner = true
            }
        }
        if gameIsActive == false && winner == false
        {
            label.text = "IT WAS A DRAW!"
            label.isHidden = false
            playAgainButton.isHidden = false
            playerTwoImage.isHidden = false
            playerOneImage.isHidden = false
            //add function where you can no longer play the game
        }
        let targetScore = UserDefaults.standard.integer(forKey: "targetScore")
        
        if playerOneScore == Int(targetScore) {
            winningPlayer = playerOneCharacter
            winnerName = playerOne
            performSegue(withIdentifier: "toGameOverViewController", sender: nil)
        } else if playerTwoScore == Int(targetScore){
            winningPlayer = playerTwoCharacter
            winnerName = playerTwo
            performSegue(withIdentifier: "toGameOverViewController", sender: nil)
        }

    }
    
    @IBOutlet weak var playAgainButton: UIButton!
    @IBAction func playAgain(_ sender: AnyObject) {
        gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        gameIsActive = true
        playAgainButton.isHidden = true
        label.isHidden = true
        if gamesPlayed.popLast() == 1 {
            activePlayer = 2
        } else {
            activePlayer = 1
        }
        
        for i in 1...9
        {
            let button = view.viewWithTag(i) as! UIButton
            button.setImage(nil, for: UIControlState())
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playerOneLabel.text = playerOne! + ": " + String(playerOneScore)
        playerTwoLabel.text = playerTwo! + ": " + String(playerTwoScore)
        playerOneImage.image = UIImage(named: playerOneCharacter!)
        playerTwoImage.image = UIImage(named: playerTwoCharacter!)
        gamesPlayed = []
    }
    override func viewWillAppear(_ animated: Bool) {
        playerOneScore = 0
        playerTwoScore = 0
        gamesPlayed = []
        winningPlayer = ""
        label.isHidden = true
        gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        //remove images
        //winner not announced
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let GameOver: GameOverViewController = segue.destination as! GameOverViewController
        
        let winner = winningPlayer
        GameOver.playerWinner = winner
        let winningName = winnerName
        GameOver.winnerName = winningName
    }
    


}

